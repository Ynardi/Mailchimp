$(window).on("scroll", function () {
   AOS.init();
 });